package Workspace;

public class AntibodyShot {

    public int xpos;
    public int ypos;
    public int dx;
    public int dy;
    public int width;
    public int height;
    public boolean isPresent;

    public AntibodyShot(int pXpos , int pYpos, int speedSetting) {
        xpos = pXpos;
        ypos = pYpos;
        //set speeds based on level/difficulty
        dx =0;
        if (speedSetting == 1){
            dy =-10;
        } else if (speedSetting == 2){
            dy =20;
        } else if (speedSetting == 3) {
            dy = 10;
        }
        width = 10;
        height = 10;
        isPresent = true;

        //count the shots taken for the level with penalties for shots after the 40th, and subtract lives accordingly
        if (Game.gameStage >= 3){
            Game.shotCounter ++;
            if (Game.shotCounter > 40){
                Game.lives --;
            }
        }
    }


    public void move() {
        xpos = xpos + dx;
        ypos = ypos + dy;
    }



}
