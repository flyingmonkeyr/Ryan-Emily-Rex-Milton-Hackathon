package Workspace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Game extends JPanel implements Runnable, ActionListener, KeyListener {

    //whether or not the game will end once lives run out
    private boolean testMode = true;
    private boolean gameOver = false;

    public static final int ENEMYWIDTH = 0;

    //Sets the width and height of the program window
    public static int WIDTH = 1000;
    public static int HEIGHT = 700;

    //spacing
    public int enemyYSpacing = 60;
    public int enemiesPerRow = 10;
    public int textXOffset = 20;

    //Declare the variables needed for the graphics
    public JFrame frame;
    public Canvas canvas;
    public JPanel panel;

    public BufferStrategy bufferStrategy;
    public Image coronaPic;
    public Image playerCell;

    public Image coronaGuy1;
    public Image coronaGuy2;
    public Image coronaGuy3;
    public Image introScreen;
    public Image antiBody;
    public Image GG;
    public boolean introPage = false;

    public ArrayList<coronaEnemy> coronaEnemies;
    public static ArrayList<AntibodyShot> antibodies;

    public static int gameStage = -1;
    public int levels = 5;
    public boolean[] levelsInitiated;

    public GameLevel L1;
    public GameLevel L2;
    public JLabel levelLabel;
    public String levelDescription;
    public String levelExplanation;
    public String levelExplanation2;
    public int shotsLeft;

    public int pauseTime = 18;
    public int levelDuration = HEIGHT*pauseTime + 1000;

    public int time;

    public IntroCorona introCorona;
    public IntroGuy introGuy;
    public Player p1;

    //holder class variable to serve different tasks
    private int holder = 0;
    public static int shotCounter = 0;

    public static int lives;
    
    public Game() {
        initGraphics();

        //none of the levels have been initiated yet
        levelsInitiated = new boolean[levels];
        for (int i = 0; i < levels; i++){
            levelsInitiated[i] = false;
        }

        coronaPic = Toolkit.getDefaultToolkit().getImage("coronavirus.png"); //load the picture
        coronaGuy1 = Toolkit.getDefaultToolkit().getImage("openmouthempty.png");
        coronaGuy2 = Toolkit.getDefaultToolkit().getImage("closedmouthempty.png");
        coronaGuy3 = Toolkit.getDefaultToolkit().getImage("closedmouthguyred.png");
        introScreen = Toolkit.getDefaultToolkit().getImage("start screen.png");
        playerCell = Toolkit.getDefaultToolkit().getImage("white blood cell for gaem.png");
        antiBody = Toolkit.getDefaultToolkit().getImage("antibody.jpg");
        GG = Toolkit.getDefaultToolkit().getImage("ggcorona.PNG");
        introCorona = new IntroCorona(10, ((HEIGHT/2)-30));
        introGuy = new IntroGuy(WIDTH-250, ((HEIGHT/2)-(200)));

        levelDescription = "N95 Mask, 12 years old, non-compromised immune system";
        levelExplanation = "Few corona enemies and no immune system penalty";
        levelExplanation2 = "Shots after the 40th subtract a life due to to immune system response";
        shotsLeft = 40;
        levelLabel = new JLabel("L1");
        L1 = new GameLevel(1);
        L2 = new GameLevel(2);

        //NUMBER OF LIVES GIVEN
        lives = 19;

        //start the player in a default position
        p1 = new Player((WIDTH/2)-30, HEIGHT-60);

        coronaEnemies = new ArrayList<coronaEnemy>();
        antibodies = new ArrayList<AntibodyShot>();

        System.out.println("adding listeners");
        //initialize key listener
        this.setFocusable(true);
        this.addKeyListener(this);
        System.out.println("listeners added");
    }

    // main thread
    public void run() {

        while (true) {
            if (gameStage != -1){
                moveThings();  //move all the game objects
            }
            this.addKeyListener(this);
            checkCollisions();
            checkLevelChange();
            checkGG();
            render();  // paint the graphics
            pause(pauseTime); // sleep for 10 ms

            //run timer starting with the first level
            if (gameStage >= 1){
                time += pauseTime;
            }
        }
    }

    public void checkGG(){
        if (lives <= 0 && !testMode){
            gameOver = true;
        }
    }

    public void checkLevelChange(){
        //check to change levels
        for (int i=0; i<levels-1; i++){
            if (gameStage == i+1){
                if (time >= levelDuration){
                    trackScores();
                    time = 0;
                    gameStage = i+2;
                }
            }
        }
    }

    private void trackScores(){

    }

    //check for collisions
    public void checkCollisions(){
        //between all antibodies and coronaEnemies; if there is a collision, both the AntibodyShot and the coronaEnemy disappears
        int AntibodiesSize;
        int CoronaEnemiesSize;
        for (int i=0; i<coronaEnemies.size(); i++){
            coronaEnemies.get(i).checkForAntibodyCollision();
        }

        //if the antibody passes the top barrier of the screen remove it from the program
        for (int i=0; i<antibodies.size(); i++){
            if (antibodies.get(i).ypos + antibodies.get(i).height <= 0){
                antibodies.get(i).isPresent = false;
            }
        }

        //remove antibodies and corona enemies as appropriate
        AntibodiesSize = antibodies.size();
        CoronaEnemiesSize = coronaEnemies.size();
        for (int i=0; i<AntibodiesSize; i++){
            if (!antibodies.get(i).isPresent){
                antibodies.remove(i);
                //need to subtract 1 from the size otherwise it doesn't work
                AntibodiesSize--;
                i--;
            }
        }
        for (int i=0; i<CoronaEnemiesSize; i++){
            if (!coronaEnemies.get(i).isAlive){
                coronaEnemies.remove(i);
                //need to subtract 1 from the size otherwise it doesn't work
                CoronaEnemiesSize--;
                i--;
            }
        }
    }


    public void moveThings() {
        //calls the move( ) code in the objects
        introCorona.move();
        for (int i = 0; i < coronaEnemies.size(); i++) {
            coronaEnemies.get(i).move();
        }
        for (int i = 0; i < antibodies.size(); i++) {
            antibodies.get(i).move();
        }
    }

    //Pauses or sleeps the computer for the amount specified in milliseconds
    public void pause(int time) {
        //sleep
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {

        }
    }

    private void initGraphics() {
        frame = new JFrame("Application Template");   //Create the program window or frame.  Names it.

        panel = (JPanel) frame.getContentPane();  //sets up a JPanel which is what goes in the frame
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));  //sizes the JPanel
        panel.setLayout(null);   //set the layout

        // creates a canvas which is a blank rectangular area of the screen onto which the application can draw
        // and trap input events (Mouse and Keyboard events)
        canvas = new Canvas();
        canvas.setBounds(0, 0, WIDTH, HEIGHT);
        canvas.setIgnoreRepaint(true);

        //add listeners for the canvas
        canvas.addKeyListener(this);

        panel.add(canvas);  // adds the canvas to the panel.

        // frame operations
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //makes the frame close and exit nicely
        frame.pack();  //adjusts the frame and its contents so the sizes are at their default or larger
        frame.setResizable(false);   //makes it so the frame cannot be resized
        frame.setVisible(true);      //IMPORTANT!!!  if the frame is not set to visible it will not appear on the screen!

        // sets up things so the screen displays images nicely.
        canvas.createBufferStrategy(2);
        bufferStrategy = canvas.getBufferStrategy();
        canvas.requestFocus();
        System.out.println("DONE graphic setup");
    }

    //paints things on the screen using bufferStrategy
    private void render() {

        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);

        //draw labels
        if (gameStage >= 1){

            g.setFont(new Font("TimesRoman", Font.PLAIN, 30));
            g.drawString("L"+gameStage+": "+levelDescription, textXOffset, 30);
            g.drawString(levelExplanation, textXOffset, 60);

            //space the other strings so that if text is long it can fit on two lines
            if (gameStage >= 3){
                g.drawString(levelExplanation2, textXOffset, 90);
                g.drawString("lives left: " + lives, textXOffset, 120);
            } else {
                g.drawString("lives left: " + lives, textXOffset, 90);
            }

            //last string display: shots remaining
            if (gameStage >= 3){
                //don't let shots left fall below 0
                if (shotCounter <= 40) {
                    g.drawString("shots left: " + (40-shotCounter), textXOffset, 150);
                } else {
                    g.drawString("shots left: 0", textXOffset, 150);
                }
            }

        }

        /* INTRO SCREEN */
        if (gameStage == -1) {//wait for the player to press space and start the game
                g.drawImage(introScreen, 0, 0, 1000, 700, null);
        }

        if (gameStage >= 1){
            //draw the corona enemies onto the screen
            for (int i = 0; i<coronaEnemies.size(); i++){
                Image coronaPicLocal = Toolkit.getDefaultToolkit().getImage("coronavirus.png"); //load the picture
                g.drawImage(coronaPicLocal, coronaEnemies.get(i).xpos, coronaEnemies.get(i).ypos, coronaEnemies.get(i).width, coronaEnemies.get(i).height, null);
            }

            //draw the player onto the screen
            g.drawImage(playerCell, p1.xpos, p1.ypos, p1.width, p1.height, null);

            //draw all the antibodyShots onto the screen
            for (int i=0; i<antibodies.size(); i++){
                if (antibodies.size() != 0){
                    g.drawImage(antiBody, antibodies.get(i).xpos, antibodies.get(i).ypos, antibodies.get(i).width, antibodies.get(i).height, null);
                }
            }
        }

        /* INTRO ANIMATION */
        if (gameStage == 0){

            //close the guys mouth when corona hits it
            checkForIntroCollision();

            //draw the corona image
            if (introGuy.openMouth){
                g.drawImage(coronaPic, introCorona.xpos, introCorona.ypos, introCorona.width, introCorona.height, null);
            }

            //draw introGuy
            if (introGuy.openMouth){
                g.drawImage(coronaGuy1, introGuy.xpos, introGuy.ypos, introGuy.width, introGuy.height, null);
            } else{
                g.drawImage(coronaGuy2, introGuy.xpos, introGuy.ypos, introGuy.width, introGuy.height, null);
            }

            //if the corona alr hit the guy: next level after a flash of the face
            if (!introGuy.openMouth){
                //determine whether to flash on or off
                if (introGuy.flashThresholdRemaining <= 0){
                    introGuy.seen = false;
                } else if (introGuy.flashThresholdRemaining > introGuy.flashThreshold){
                    introGuy.seen = true;
                    holder++;
                }
                // flash the face of the guy
                if (introGuy.seen){
                    introGuy.flashThresholdRemaining -= pauseTime;
                    g.drawImage(coronaGuy3, introGuy.xpos, introGuy.ypos, introGuy.width, introGuy.height, null);
                }else{
                    introGuy.flashThresholdRemaining += pauseTime;
                    g.clearRect(0, 0, WIDTH, HEIGHT);
                }

                //if the holder reaches the flashing amount, go to the next stage of the game
                if (holder >= 5){
                    gameStage = 1;
                }
            }

        }

        /* LEVEL 1 */
        else if (gameStage == 1){
            //only run once
            if (!levelsInitiated[0]){
                levelsInitiated[0] = true;
                initiateL1();
            }
        }


        /* LEVEL 2 */
        else if (gameStage == 2){
            //only run once
            if (!levelsInitiated[1]){
                levelsInitiated[1] = true;
                initiateL2();
            }
        }

        /* LEVEL 3 */
        else if (gameStage == 3){
            //only run once
            if (!levelsInitiated[2]){
                levelsInitiated[2] = true;
                initiateL3();
            }
        }

        /* LEVEL 4 */
        else if (gameStage == 4){
            //only run once
            if (!levelsInitiated[3]){
                levelsInitiated[3] = true;
                initiateL4();
            }
        }

        /* LEVEL 5 */
        else if (gameStage == 5){
            //only run once
            if (!levelsInitiated[4]){
                levelsInitiated[4] = true;
                initiateL5();
            }
        }

        //gg test
        if (gameOver){
            g.drawImage(GG, 0, 0, 1000, 700, this);
        }

        g.dispose();

        bufferStrategy.show();
    }

    private void initiateL5(){
        levelDescription = "NO MASK, 80 years old, compromised immune system";
        levelExplanation = "More corona; immune system usage penalty, coronas do";
        levelExplanation2 = "3 damage, not possible to use over 40 shots";
        System.out.println("initializing level 5");
        //init coronaEnemies
        coronaEnemies.clear();
        shotCounter = 0;
        for (int i=0; i<L2.num_enemies; i++){
            //up to five enemies per row
            coronaEnemies.add(new coronaEnemy((((i+1)%(enemiesPerRow))+1)*(WIDTH/(enemiesPerRow+1))-30, ((((i))/(enemiesPerRow))*enemyYSpacing + enemyYSpacing/2)-30));
            //error print
            System.out.println(coronaEnemies.get(i).intoString());
        }
    }

    private void initiateL4(){
        levelDescription = "NO MASK, 80 years old, non-compromised immune system";
        levelExplanation = "More corona; immune system usage penalty, each corona";
        levelExplanation2 = "enemy that passes takes three lives away due to fragility";
        System.out.println("initializing level 4");
        //init coronaEnemies
        coronaEnemies.clear();
        shotCounter = 0;
        for (int i=0; i<L2.num_enemies; i++){
            //up to five enemies per row
            coronaEnemies.add(new coronaEnemy((((i+1)%(enemiesPerRow))+1)*(WIDTH/(enemiesPerRow+1))-30, ((((i))/(enemiesPerRow))*enemyYSpacing + enemyYSpacing/2)-30));
            //error print
            System.out.println(coronaEnemies.get(i).intoString());
        }
    }

    private void initiateL3(){
        levelDescription = "NO MASK, 60 years old, non-compromised immune system";
        levelExplanation = "More corona enemies; immune system usage penalty: ";
        System.out.println("initializing level 3");
        //init coronaEnemies
        coronaEnemies.clear();
        shotCounter = 0;
        for (int i=0; i<L2.num_enemies; i++){
            //up to five enemies per row
            coronaEnemies.add(new coronaEnemy((((i+1)%(enemiesPerRow))+1)*(WIDTH/(enemiesPerRow+1))-30, ((((i))/(enemiesPerRow))*enemyYSpacing + enemyYSpacing/2)-30));
            //error print
            System.out.println(coronaEnemies.get(i).intoString());
        }
    }

    private void initiateL2(){
        levelDescription = "NO MASK, 12 years old, non-compromised immune system";
        levelExplanation = "More corona enemies; no immune system usage penalty";
        System.out.println("initializing level 2");
        //init coronaEnemies
        coronaEnemies.clear();

        for (int i=0; i<L2.num_enemies; i++){
            //up to five enemies per row
            coronaEnemies.add(new coronaEnemy((((i+1)%(enemiesPerRow))+1)*(WIDTH/(enemiesPerRow+1))-30, ((((i))/(enemiesPerRow))*enemyYSpacing + enemyYSpacing/2)-30));
            //error print
            System.out.println(coronaEnemies.get(i).intoString());
        }
    }

    private void initiateL1() {
        levelDescription = "N95 Mask, 12 years old, non-compromised immune system";
        System.out.println("initializing level 1");
        for (int i=0; i<L1.num_enemies; i++){
            //up to five enemies per row
            coronaEnemies.add(new coronaEnemy((((i+1)%(enemiesPerRow))+1)*(WIDTH/(enemiesPerRow+1))-30, (((((i)/(enemiesPerRow))*enemyYSpacing)) + enemyYSpacing/2)-30));
            //error print
            System.out.println(coronaEnemies.get(i).intoString());
        }
    }


    private void checkForIntroCollision(){
        if((introCorona.xpos+introCorona.width) > introGuy.xpos){
            introGuy.openMouth = false;
        }
    }

    private void shootAntibody(){

        //level 5 only permits 40 shots
        if (!(gameStage == 5)){
            antibodies.add(new AntibodyShot(p1.xpos + (p1.width/2) - 5, p1.ypos, 1));
        } else if (gameStage == 5){
            if (shotCounter < 40){
                antibodies.add(new AntibodyShot(p1.xpos + (p1.width/2) - 5, p1.ypos, 1));
            }
        }

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //space
        int key = e.getKeyCode();
        if (key == 32) {

            //start the game if space pressed on introPage
            if (gameStage == -1){
                gameStage = 0;
            }
            //shoot antibody otherwise
            else {
                shootAntibody();
            }
        }
        //left and right arrows move the player
        //left
        else if (key == 37) {
            p1.left();
        }
        //right
        else if (key == 39) {
            p1.right();
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }

    public void actionPerformed(ActionEvent e) {

    }
}
