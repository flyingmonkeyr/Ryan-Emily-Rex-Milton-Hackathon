package Workspace;

public class coronaEnemy {

    public String name;                //holds the name of the hero
    public int xpos;                //the x position
    public int ypos;                //the y position
    public int dx;                    //the speed of the hero in the x direction
    public int dy;                    //the speed of the hero in the y direction
    public int width;
    public int height;
    public boolean isAlive;

    public coronaEnemy(int pXpos, int pYpos) {
        xpos = pXpos;
        ypos = pYpos;
        dx = 0;
        dy = 1;
        width = 60;
        height = 60;
        isAlive = true;

    } // constructor

    //The move method.  Everytime this is run (or "called") the hero's x position and y position change by dx and dy
    public void move() {
        xpos = xpos + dx;
        ypos = ypos + dy;

        checkForBottomCollision();
    }

    public String intoString() {
        return "xpos: " + Integer.toString(xpos) + ", ypos: " + Integer.toString(ypos);
    }

    public void checkForBottomCollision() {
        if (ypos > Game.HEIGHT) {
            //kill the enemy and reduce lives by 1 when it passes the bottom barrier
            isAlive = false;

            //different life loss based on game level
            if (Game.gameStage >= 4){
                Game.lives -= 3;
            } else {
                Game.lives--;
            }
        }
    }

    public void checkForAntibodyCollision() {
        //between all antibodies and this coronaEnemy; if there is a collision, both the AntibodyShot and the coronaEnemy disappears
        int AntibodiesSize;
        int CoronaEnemiesSize;
        for (int i = 0; i < Game.antibodies.size(); i++) {


            //top left corner of antibody is inside the coronaEnemy bounding box
            if (Game.antibodies.get(i).xpos >= this.xpos && Game.antibodies.get(i).xpos <= this.xpos + this.width && Game.antibodies.get(i).ypos <= this.ypos + this.height && Game.antibodies.get(i).ypos >= this.ypos) {
                Game.antibodies.get(i).isPresent = false;
                this.isAlive = false;
            }

            //top right corner of antibody is inside the coronaEnemy bounding box
            else if (Game.antibodies.get(i).xpos + Game.antibodies.get(i).width >= this.xpos && Game.antibodies.get(i).xpos + Game.antibodies.get(i).width <= this.xpos + this.width && Game.antibodies.get(i).ypos <= this.ypos + this.height && Game.antibodies.get(i).ypos >= this.ypos) {
                Game.antibodies.get(i).isPresent = false;
                this.isAlive = false;
            }

            //bottom left corner of antibody is inside the coronaEnemy bounding box
            else if (Game.antibodies.get(i).xpos >= this.xpos && Game.antibodies.get(i).xpos <= this.xpos + this.width && Game.antibodies.get(i).ypos + Game.antibodies.get(i).height <= this.ypos + this.height && Game.antibodies.get(i).ypos + Game.antibodies.get(i).height >= this.ypos) {
                Game.antibodies.get(i).isPresent = false;
                this.isAlive = false;
            }

            //bottom right corner of antibody is inside the coronaEnemy bounding box
            else if (Game.antibodies.get(i).xpos + Game.antibodies.get(i).width >= this.xpos && Game.antibodies.get(i).xpos + Game.antibodies.get(i).width <= this.xpos + this.width && Game.antibodies.get(i).ypos + Game.antibodies.get(i).height <= this.ypos + this.height && Game.antibodies.get(i).ypos + Game.antibodies.get(i).height >= this.ypos) {
                Game.antibodies.get(i).isPresent = false;
                this.isAlive = false;
            }
        }

    }
}