package Workspace;

public class Player {

    public String name;                //holds the name of the hero
    public int xpos;                //the x position
    public int ypos;                //the y position
    public int dx;                    //the speed of the hero in the x direction
    public int dy;                    //the speed of the hero in the y direction
    public int width;
    public int height;
    public boolean isAlive;
    public int speed;


    public Player(int pXpos , int pYpos) {
        xpos = pXpos;
        ypos = pYpos;
        dx =0;
        dy =1;
        width = 60;
        height = 60;
        isAlive = true;
        speed = 20;
    } // constructor

    //The move method.  Everytime this is run (or "called") the hero's x position and y position change by dx and dy
    public void move() {
        xpos = xpos + dx;
        ypos = ypos + dy;
    }

    public void left(){
        xpos = xpos - speed;
    }
    public void right(){
        xpos = xpos + speed;
    }


    public String intoString(){
        return "xpos: "+Integer.toString(xpos)+", ypos: "+Integer.toString(ypos);
    }

}
