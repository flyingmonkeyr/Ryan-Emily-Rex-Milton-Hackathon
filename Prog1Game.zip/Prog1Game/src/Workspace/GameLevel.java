package Workspace;

public class GameLevel {

    public int num_enemies;


    public GameLevel(int level){
        if (level == 1){
            num_enemies = 20;
        } else if (level == 2){
            num_enemies = 40;
        }

}

}