package Workspace;

public class IntroGuy {
    //VARIABLE DECLARATION SECTION
    //Here's where you state which variables you are going to use.
    public int xpos;                //the x position
    public int ypos;                //the y position
    public int width;
    public int height;
    //open or closed mouth
    public int state;
    public boolean openMouth = true;
    public boolean seen = true;
    //will flash every 300 ms
    public int flashThreshold = 100;
    public int flashThresholdRemaining = 100;



    // METHOD DEFINITION SECTION

    // Constructor Definition
    // A constructor builds the object when called and sets variable values.


    //This is a SECOND constructor that takes 3 parameters.  This allows us to specify the hero's name and position when we build it.
    // if you put in a String, an int and an int the program will use this constructor instead of the one above.
    public IntroGuy(int pXpos , int pYpos) {
        xpos = pXpos;
        ypos = pYpos;
        width = 200;
        height = 300;

    } // constructor

    //The move method.  Everytime this is run (or "called") the hero's x position and y position change by dx and dy
//    public int animate() {
//        if (openMouth){
//            openMouth = false;
//            return 1;
//        }
//        else {
//            openMouth = true;
//            return 2;
//        }
//    }
}
