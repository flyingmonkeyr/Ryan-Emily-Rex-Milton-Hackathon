package Workspace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Random;

//will handle all the floor instantiation

public class FloorLayout {

    /*"3D" array:
    - Array of 18 floors
    - Floor returns a matrix
    - Matrix is 2D, laying out the room, pathways, walls etc.
    - Each item in the 2D array is a state (wall, path, etc.) that is common across the game
     */
    /*int represents whether the tile is:
    1. path
    2. open space
    3. wall
     */
    public Floor[] floors = new Floor[18];

    //create the floors in the construction method
    public FloorLayout() {

        int[][] inputMatrix;
        int openingVal;
        int[] topDoorwayLocations;
        int[] bottomDoorwayLocations;
        int topPathwayWallVal;
        int bottomPathwayWallVal;
        int[] topWallLocations;
        int[] bottomWallLocations;

        //for each floor in the matrix of 18 floors
        for (int i = 0; i < floors.length; i++) {

            inputMatrix = new int[14][20];
            openingVal = findOpening();
            topDoorwayLocations = findDoorwayValues();
            bottomDoorwayLocations = findDoorwayValues();
            topPathwayWallVal = openingVal - 1;
            bottomPathwayWallVal = openingVal + 2;
            topWallLocations = findWallValues(topDoorwayLocations);
            bottomWallLocations = findWallValues(bottomDoorwayLocations);

            //initialize all tiles at 0
            for (int j=0; j<inputMatrix.length; j++){
                for (int k=0; k<inputMatrix[j].length; k++){
                    inputMatrix[j][k] = 0;
                }
            }

            //cycling through the rows in the matrix
            for (int j = 0; j < inputMatrix.length; j++) {

                /*draw the matrix:
                1. draw the pathway/vertical walls, and then each horizontal wall based on variables
                2. draw open spaces (=2, where people can be spawned) everywhere else (where the pixel == null)
                 */

                //draw all the vertical walls: left and right edges of the floor
                for (int k = 0; k < inputMatrix[j].length; k++) {
                    //first or last "x value"
                    if (k == 0 || k == inputMatrix[j].length - 1) {
                        inputMatrix[j][k] = 3;
                    }
                }

                //draw the corridor that leads to rooms on either side
                if (j == openingVal || j == openingVal + 1) {
                    //these two rows get cleared for pathway, saving last pixel for wall
                    for (int k = 0; k < inputMatrix[j].length - 1; k++) {
                        inputMatrix[j][k] = 1;
                    }
                }

                //walls on top and bottom, and on either side of the pathway
                if (j == 0 || j == inputMatrix.length-1 || j == topPathwayWallVal || j == bottomPathwayWallVal) {
                    //these four rows become walls, saving last pixel for wall
                    for (int k = 0; k < inputMatrix[j].length - 1; k++) {
                        inputMatrix[j][k] = 3;
                    }
                }

                //"cut" doorways in the walls on either side of the pathway
                if (j == topPathwayWallVal || j == bottomPathwayWallVal) {
                    //cut the doorway by changing the tile from a wall (3) to a pathway (1)
                    if (j == topPathwayWallVal) {
                        for (int k = 0; k < inputMatrix[j].length - 1; k++) {
                            for (int l = 0; l < topDoorwayLocations.length; l++) {
                                inputMatrix[j][topDoorwayLocations[l]] = 1;
                            }
                        }
                    } else if (j == bottomPathwayWallVal) {
                        for (int k = 0; k < inputMatrix[j].length - 1; k++) {
                            for (int l = 0; l < bottomDoorwayLocations.length; l++) {
                                inputMatrix[j][bottomDoorwayLocations[l]] = 1;
                            }
                        }
                    }
                }

                //room dividing walls
                for (int k = 0; k < inputMatrix[j].length; k++) {
                    //specified "x values"

                    //upper walls: between horizontal walls at x values specified in topWallLocations[]
                    for (int l=0; l<topWallLocations.length; l++){
                        if (k > 0 && k < topPathwayWallVal){
                            inputMatrix[k][topWallLocations[l]] = 3;
                        }
                    }

                    //lower walls: between horizontal walls at x values specified in bottomWallLocations[]
                    for (int l=0; l<bottomWallLocations.length; l++){
                        if (k < inputMatrix.length-1 && k > bottomPathwayWallVal){
                            inputMatrix[k][bottomWallLocations[l]] = 3;
                        }
                    }
                }

            }

            //now, add open spaces on any null (value 0) tile
            for (int j=0; j<inputMatrix.length; j++){
                for (int k=0; k<inputMatrix[j].length; k++){
                    if (inputMatrix[j][k] == 0){
                        inputMatrix[j][k] = 2;
                    }
                }
            }

            //add the matrix to the array through Floor
            floors[i] = new Floor(inputMatrix);
        }
    }

    //returns value from 3-9, from column values 0-13, randomly generated for the two-pixel opening (number represents the top opening)
    public int findOpening() {
        int max = 10;
        int min = 3;
        System.out.println((int) Math.random() * (max - min + 1) + min);
        return (int) (Math.random() * (max - min + 1) + min);
    }

    //returns 3-long array with the doorway values
    public int[] findDoorwayValues() {
        int[] values = new int[3];
        for (int i = 0; i < 3; i++) {
            //-2 to a. -1 for the difference between 0 and 1; b. ensure that two openings will not be next to each other
            int max = 6 * (i + 1) - 2;
            int min = 6 * i;
            int generatedVal = (int) (Math.random() * (max - min + 1) + min);
            //add one bc first column is a wall
            values[i] = generatedVal + 1;
        }
        return values;
    }

    //returns 2-long array with the x values for walls between rooms
    public int[] findWallValues(int[] doorwayValues) {

        int[] values = new int[2];
        //# of walls will be 1 fewer than the # of doorways

        //random true/false
        boolean randomBool;
        if (Math.random() < 0.5) {
            randomBool = true;
        } else {
            randomBool = false;
        }

        //50% of time: put adjacent to left walls, otherwise put adjacent to right walls
        if (randomBool) {
            for (int i=0; i<values.length; i++){
                values[i] = doorwayValues[i] + 1;
            }
        } else {
            for (int i=0; i<values.length; i++){
                values[i] = doorwayValues[i+1] - 1;
            }
        }

        return values;
    }

    //int randomValue = (int) Math.random() * (max - min + 1) + min;

}
