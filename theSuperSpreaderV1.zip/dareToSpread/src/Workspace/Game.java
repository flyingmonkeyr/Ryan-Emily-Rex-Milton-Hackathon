package Workspace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.BufferStrategy;
import java.lang.reflect.Array;
import java.util.ArrayList;

public class Game extends JPanel implements Runnable, ActionListener, KeyListener, MouseListener {

    public int SCORE = 0;

    //whether or not the game will end once lives run out
    private boolean testMode = true;
    private boolean gameOver = false;

    private int testFloor = 0;

    //Sets the width and height of the program window
    public static int WIDTH = 1000;
    public static int HEIGHT = 700;

    //Declare the variables needed for the graphics
    public JFrame frame;
    public Canvas canvas;
    public JPanel panel;

    //graphics buffering i think
    public BufferStrategy bufferStrategy;

    //images
    public Image one;

    FloorLayout floorLayout;

    /* 2D arrayList:
    - each floor has an arrayList of all the characters there
     */
    public ArrayList<ArrayList<Infectee>> allInfectees;

    //intro page, floor etc.
    public static int gameStage = -1;

    //each frame's time onscreen in ms
    public int pauseTime = 18;

    //for timers
    public int time;

    public Player p1;


    //initialization and stuff
    public Game(){
        p1 = new Player();

        initGraphics();
        //initialize all floors
        floorLayout = new FloorLayout();

        this.setFocusable(true);
        this.addKeyListener(this);
        this.addMouseListener(this);
    }

    //graphics initialization
    private void initGraphics() {
        frame = new JFrame("Application Template");   //Create the program window or frame.  Names it.

        panel = (JPanel) frame.getContentPane();  //sets up a JPanel which is what goes in the frame
        panel.setPreferredSize(new Dimension(WIDTH, HEIGHT));  //sizes the JPanel
        panel.setLayout(null);   //set the layout

        // creates a canvas which is a blank rectangular area of the screen onto which the application can draw
        // and trap input events (Mouse and Keyboard events)
        canvas = new Canvas();
        canvas.setBounds(0, 0, WIDTH, HEIGHT);
        canvas.setIgnoreRepaint(true);

        //add listeners for the canvas
        canvas.addKeyListener(this);
        canvas.addMouseListener(this);

        panel.add(canvas);  // adds the canvas to the panel.

        // frame operations
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  //makes the frame close and exit nicely
        frame.pack();  //adjusts the frame and its contents so the sizes are at their default or larger
        frame.setResizable(false);   //makes it so the frame cannot be resized
        frame.setVisible(true);      //IMPORTANT!!!  if the frame is not set to visible it will not appear on the screen!

        // sets up things so the screen displays images nicely.
        canvas.createBufferStrategy(2);
        bufferStrategy = canvas.getBufferStrategy();
        canvas.requestFocus();
        System.out.println("DONE graphic setup");
    }

    // main thread
    public void run() {

        while (true) {
            if (gameStage != -1){
                moveThings();  //move all the game objects
            }
            this.addKeyListener(this);
            this.addMouseListener(this);
            checkCollisions();
            checkGG();
            render();  // paint the graphics
            pause(pauseTime); // sleep for 10 ms

            //run timer starting with the first level
            if (gameStage >= 1){
                time += pauseTime;
            }
        }
    }

    public void checkGG(){

    }

    public void moveThings() {
        //calls the move( ) code in the objects

    }


    //check for collisions
    public void checkCollisions(){
        //between the player and walls, characters
        //between sneeze/cough clouds and characters

    }



    //Pauses or sleeps the computer for the amount specified in milliseconds
    public void pause(int time) {
        //sleep
        try {
            Thread.sleep(time);
        } catch (InterruptedException e) {

        }
    }

    //paints things on the screen using bufferStrategy
    private void render() {

        Graphics2D g = (Graphics2D) bufferStrategy.getDrawGraphics();
        g.clearRect(0, 0, WIDTH, HEIGHT);

        int tileWidth = Game.WIDTH/floorLayout.floors[testFloor].tileMatrix[0].length;
        int tileHeight = Game.HEIGHT/floorLayout.floors[testFloor].tileMatrix.length;



        //draw the floor by cycling through each pixel in a floor
        for (int i=0; i<floorLayout.floors[testFloor].tileMatrix.length; i++){
            for (int j=0; j<floorLayout.floors[testFloor].tileMatrix[i].length; j++){
                //Tile coordinates
                int topLeftCornerX = tileWidth*j;
                int topLeftCornerY = tileHeight*i;
                if (floorLayout.floors[testFloor].tileMatrix[i][j] == 1){
                    g.setColor(Color.yellow);
                } else if (floorLayout.floors[testFloor].tileMatrix[i][j] == 2){
                    g.setColor(Color.white);
                } else if (floorLayout.floors[testFloor].tileMatrix[i][j] == 3){
                    g.setColor(Color.black);
                }

                g.fillRect(topLeftCornerX, topLeftCornerY, 50, 50);
            }
        }

        g.dispose();
        bufferStrategy.show();
    }


        @Override
    public void actionPerformed(ActionEvent e) {

    }

    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        //space
        int key = e.getKeyCode();
        if (key == 32) {

            //start the game if space pressed on introPage
            if (gameStage == -1){
                gameStage = 0;
            }
            //cough/sneeze
            else {
                //cough/sneeze
            }
        }
        //left and right arrows move the player
        //left
        else if (key == 37) {
            //move player
            testFloor--;
        }
        //right
        else if (key == 39) {
            //move player
            testFloor ++;
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {

    }


    @Override
    public void mouseClicked(MouseEvent e) {

    }

    @Override
    public void mousePressed(MouseEvent e) {

    }

    @Override
    public void mouseReleased(MouseEvent e) {

    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {

    }
}
