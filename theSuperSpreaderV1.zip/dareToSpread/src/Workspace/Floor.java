package Workspace;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.awt.image.BufferStrategy;
import java.lang.reflect.Array;
import java.util.ArrayList;


public class Floor{

    /*int represents whether the tile is:
    1. path
    2. open space
    3. wall
     */
    //# rows: tileMatrix.length; # columns: tileMatrix[i].length
    public int[][] tileMatrix;
    int tileWidth;
    int tileHeight;

    //construction
    public Floor(int[][] inputMatrix){

        tileMatrix = inputMatrix;

        tileWidth = Game.WIDTH/tileMatrix[0].length;
        tileHeight = Game.HEIGHT/tileMatrix.length;

    }

    public boolean touchingWall(int x, int y){

        for (int i=0; i<(tileMatrix.length); i++){

            for (int j=0; j<tileMatrix[0].length; j++){
                //bounding box for given "pixel"

                //check if wall
                if (tileMatrix[i][j] == 3){
                    //Tile coordinates
                    int topLeftCornerX = tileWidth*j;
                    int topLeftCornerY = tileHeight*i;
                    System.out.println("X: " + topLeftCornerX + "; Y: " + topLeftCornerY);

                    //check if inside bounding box
                    if (topLeftCornerX <= x && topLeftCornerX + tileWidth >= x && topLeftCornerY <= y && topLeftCornerY + tileHeight >= y){
                        return true;
                    }

                }

            }

        }

        //else:
        return false;
    }

}
