package Workspace;

public class Player {
}
