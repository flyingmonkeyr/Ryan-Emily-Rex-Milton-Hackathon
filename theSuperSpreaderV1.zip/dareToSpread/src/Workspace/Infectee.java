package Workspace;

public class Infectee {
}
