package Workspace;

public class Main {

    public static void main(String[] args) {
        // write your code here
        //run the program through another class
        Game game = new Game();   //creates a new instance of the game
        game.run();                 //calls the run method from the BasicGameApp method
    }
}
